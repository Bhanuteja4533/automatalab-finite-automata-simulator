const $ = id => document.getElementById(id);

const presets = {
  ends1: {
    name: "Ends with 1", states: ["q0","q1"], alphabet: ["0","1"], start: "q0", finals: ["q1"],
    transitions: {q0: {"0":"q0","1":"q1"}, q1: {"0":"q0","1":"q1"}}
  },
  contains01: {
    name: "Contains 01", states: ["q0","q1","q2"], alphabet: ["0","1"], start: "q0", finals: ["q2"],
    transitions: {q0: {"0":"q1","1":"q0"}, q1: {"0":"q1","1":"q2"}, q2: {"0":"q2","1":"q2"}}
  },
  even0: {
    name: "Even number of 0s", states: ["q0","q1"], alphabet: ["0","1"], start: "q0", finals: ["q0"],
    transitions: {q0: {"0":"q1","1":"q0"}, q1: {"0":"q0","1":"q1"}}
  }
};
let dfa = structuredClone(presets.ends1);
let lastRun = null;

function csv(value) { return value.split(",").map(x => x.trim()).filter(Boolean); }
function escapeXml(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"}[c])); }

function updateStats() {
  $("statName").textContent = dfa.name || "Custom DFA";
  $("statStates").textContent = dfa.states.length;
  $("statAlphabet").textContent = `{${dfa.alphabet.join(", ")}}`;
  $("statFinals").textContent = dfa.finals.length;
}

function updateStartOptions(selected = dfa.start) {
  $("startState").replaceChildren();
  dfa.states.forEach(s => {
    const opt = document.createElement("option");
    opt.value = s; opt.textContent = s; opt.selected = s === selected;
    $("startState").appendChild(opt);
  });
}

function renderEditor() {
  const table = $("editorTable");
  table.replaceChildren();
  const head = document.createElement("tr");
  ["State", ...dfa.alphabet.map(a => `Input ${a}`)].forEach(label => {
    const th = document.createElement("th"); th.textContent = label; head.appendChild(th);
  });
  table.appendChild(head);
  dfa.states.forEach(state => {
    const tr = document.createElement("tr");
    const name = document.createElement("td"); name.textContent = state; tr.appendChild(name);
    dfa.alphabet.forEach(symbol => {
      const td = document.createElement("td");
      const select = document.createElement("select");
      select.dataset.state = state; select.dataset.symbol = symbol;
      dfa.states.forEach(target => {
        const option = document.createElement("option");
        option.value = target; option.textContent = target;
        option.selected = dfa.transitions[state]?.[symbol] === target;
        select.appendChild(option);
      });
      td.appendChild(select); tr.appendChild(td);
    });
    table.appendChild(tr);
  });
}

function renderTable() {
  const table = $("transitionTable");
  table.replaceChildren();
  const head = document.createElement("tr");
  ["State", ...dfa.alphabet.map(a => `δ(${a})`)].forEach(label => {
    const th = document.createElement("th"); th.textContent = label; head.appendChild(th);
  });
  table.appendChild(head);
  dfa.states.forEach(state => {
    const tr = document.createElement("tr");
    const td = document.createElement("td"); td.textContent = `${state}${state === dfa.start ? " ↤" : ""}${dfa.finals.includes(state) ? " ★" : ""}`; tr.appendChild(td);
    dfa.alphabet.forEach(symbol => {
      const cell = document.createElement("td"); cell.textContent = dfa.transitions[state]?.[symbol] ?? "—"; tr.appendChild(cell);
    });
    table.appendChild(tr);
  });
}

function renderGraph(activeState = null) {
  const n = dfa.states.length;
  const width = Math.max(440, n * 145 + 80), height = 225;
  const positions = {};
  const spacing = (width - 100) / Math.max(n, 1);
  dfa.states.forEach((s, i) => positions[s] = {x: 50 + spacing * (i + .5), y: 112});
  let edges = "";
  const defs = `<defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L0,6 L7,3 z" fill="#8290aa"/></marker></defs>`;
  dfa.states.forEach(from => {
    const grouped = {};
    dfa.alphabet.forEach(symbol => {
      const to = dfa.transitions[from]?.[symbol];
      if (!to) return;
      (grouped[to] ||= []).push(symbol);
    });
    Object.entries(grouped).forEach(([to, symbols]) => {
      const a = positions[from], b = positions[to];
      const label = escapeXml(symbols.join(","));
      if (from === to) {
        edges += `<path d="M ${a.x-16} ${a.y-24} C ${a.x-65} ${a.y-88}, ${a.x+65} ${a.y-88}, ${a.x+16} ${a.y-24}" fill="none" stroke="#8290aa" stroke-width="1.7" marker-end="url(#arrow)"/>`;
        edges += `<text x="${a.x}" y="${a.y-68}" text-anchor="middle" fill="#53627a" font-size="12">${label}</text>`;
      } else {
        const dir = b.x > a.x ? 1 : -1;
        const startX = a.x + dir*25, endX = b.x - dir*29;
        const curveY = (from.charCodeAt(from.length-1) + to.charCodeAt(to.length-1)) % 2 ? 18 : -18;
        edges += `<path d="M ${startX} ${a.y} Q ${(a.x+b.x)/2} ${a.y+curveY} ${endX} ${b.y}" fill="none" stroke="#8290aa" stroke-width="1.7" marker-end="url(#arrow)"/>`;
        edges += `<text x="${(a.x+b.x)/2}" y="${a.y+curveY-7}" text-anchor="middle" fill="#53627a" font-size="12">${label}</text>`;
      }
    });
  });
  let nodes = "";
  dfa.states.forEach(s => {
    const p = positions[s], isFinal = dfa.finals.includes(s), active = s === activeState;
    if (s === dfa.start) {
      nodes += `<path d="M ${p.x-52} ${p.y} L ${p.x-31} ${p.y}" stroke="#315bea" stroke-width="2" marker-end="url(#arrow)"/>`;
    }
    nodes += `<circle cx="${p.x}" cy="${p.y}" r="27" fill="${active ? "#dbe7ff" : "#fff"}" stroke="${active ? "#315bea" : (isFinal ? "#16845b" : "#9aa7bb")}" stroke-width="${active ? 3 : 2}"/>`;
    if (isFinal) nodes += `<circle cx="${p.x}" cy="${p.y}" r="22" fill="none" stroke="#16845b" stroke-width="1.5"/>`;
    nodes += `<text x="${p.x}" y="${p.y+4}" text-anchor="middle" fill="#17243a" font-size="12" font-weight="700">${escapeXml(s)}</text>`;
  });
  $("graph").innerHTML = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="DFA state transition diagram">${defs}${edges}${nodes}</svg>`;
}

function renderAll(activeState = null) {
  updateStats(); renderTable(); renderEditor(); renderGraph(activeState);
}

function simulate() {
  const input = $("inputString").value;
  const chars = Array.from(input);
  const invalid = chars.find(ch => !dfa.alphabet.includes(ch));
  const box = $("resultBox");
  $("trace").replaceChildren();
  if (invalid !== undefined) {
    box.className = "result-box rejected";
    box.innerHTML = `<span class="result-symbol">!</span><div><strong>Invalid input symbol</strong><p>The symbol “${escapeXml(invalid)}” is not in the alphabet {${dfa.alphabet.join(", ")}}.</p></div>`;
    $("trace").innerHTML = '<div class="empty-state">No simulation was performed because the input contains an invalid symbol.</div>';
    $("traceCount").textContent = "0 steps"; lastRun = null; renderGraph(); return;
  }
  let state = dfa.start;
  const steps = [{index:0, symbol:"ε", from:"—", to:state, note:"Initial state"}];
  for (let i = 0; i < chars.length; i++) {
    const from = state, symbol = chars[i];
    state = dfa.transitions[from]?.[symbol];
    if (!state) {
      box.className = "result-box rejected";
      box.innerHTML = `<span class="result-symbol">!</span><div><strong>Incomplete transition function</strong><p>No transition is defined from ${escapeXml(from)} on ${escapeXml(symbol)}.</p></div>`;
      $("trace").innerHTML = '<div class="empty-state">Please complete all transition rules in the custom DFA builder.</div>';
      $("traceCount").textContent = `${i} steps`; lastRun = null; renderGraph(from); return;
    }
    steps.push({index:i+1, symbol, from, to:state, note:`Read ${symbol}`});
  }
  const accepted = dfa.finals.includes(state);
  box.className = `result-box ${accepted ? "accepted" : "rejected"}`;
  box.innerHTML = `<span class="result-symbol">${accepted ? "✓" : "×"}</span><div><strong>${accepted ? "STRING ACCEPTED" : "STRING REJECTED"}</strong><p>${input.length ? `Input “${escapeXml(input)}”` : "The empty string ε"} finished in ${escapeXml(state)}. ${accepted ? "This is an accepting state." : "This is not an accepting state."}</p></div>`;
  steps.forEach((step, i) => {
    const row = document.createElement("div"); row.className = `trace-row ${i === steps.length-1 ? "current" : ""}`;
    const index = document.createElement("span"); index.className = "trace-index"; index.textContent = step.index;
    const main = document.createElement("span"); main.innerHTML = `<b>${escapeXml(step.note)}</b><br><span class="trace-transition">${escapeXml(step.from)} → ${escapeXml(step.to)}</span>`;
    const pill = document.createElement("span"); pill.className = "state-pill"; pill.textContent = step.to;
    row.append(index, main, pill); $("trace").appendChild(row);
  });
  $("traceCount").textContent = `${chars.length} input step${chars.length === 1 ? "" : "s"}`;
  lastRun = {input, state}; renderGraph(state);
}

function loadPreset(key) {
  if (!presets[key]) return;
  dfa = structuredClone(presets[key]);
  $("stateNames").value = dfa.states.join(", ");
  $("alphabet").value = dfa.alphabet.join(", ");
  $("finalStates").value = dfa.finals.join(", ");
  updateStartOptions(dfa.start);
  $("builderMessage").textContent = "";
  $("resultBox").className = "result-box neutral";
  $("resultBox").innerHTML = '<span class="result-symbol">i</span><div><strong>Ready to simulate</strong><p>Select an input string and run the automaton.</p></div>';
  $("trace").innerHTML = '<div class="empty-state">Your state-by-state execution will appear here.</div>';
  $("traceCount").textContent = "0 steps";
  lastRun = null; renderAll();
}


function refreshBuilderEditor() {
  const states = csv($("stateNames").value);
  const alphabet = csv($("alphabet").value);
  if (!states.length || !alphabet.length) return message("Add at least one state and one alphabet symbol.", true);
  if (new Set(states).size !== states.length || new Set(alphabet).size !== alphabet.length) return message("States and alphabet symbols must not contain duplicates.", true);
  if (states.some(s => /[\s,]/.test(s)) || alphabet.some(a => /[\s,]/.test(a))) return message("Use single names/symbols without spaces (e.g. q0, q1 and 0, 1).", true);
  const old = dfa;
  const start = states.includes(old.start) ? old.start : states[0];
  const finals = csv($("finalStates").value).filter(s => states.includes(s));
  const transitions = {};
  states.forEach(s => {
    transitions[s] = {};
    alphabet.forEach(a => {
      const oldTarget = old.transitions[s]?.[a];
      transitions[s][a] = states.includes(oldTarget) ? oldTarget : states[0];
    });
  });
  dfa = {name:"Custom DFA", states, alphabet, start, finals, transitions};
  updateStartOptions(start);
  renderAll();
  message("Transition editor refreshed. Choose each destination state, then apply the DFA.", false);
}

function applyCustom() {
  const states = csv($("stateNames").value);
  const alphabet = csv($("alphabet").value);
  const start = $("startState").value;
  const finals = csv($("finalStates").value);
  if (!states.length || !alphabet.length) return message("Add at least one state and one alphabet symbol.", true);
  if (new Set(states).size !== states.length || new Set(alphabet).size !== alphabet.length) return message("States and alphabet symbols must not contain duplicates.", true);
  if (states.some(s => /[\s,]/.test(s)) || alphabet.some(a => /[\s,]/.test(a))) return message("Use single names/symbols without spaces (e.g. q0, q1 and 0, 1).", true);
  if (!states.includes(start) || finals.some(s => !states.includes(s))) return message("Start state and every final state must exist in your state list.", true);
  const transitions = {};
  states.forEach(s => transitions[s] = {});
  const rows = Array.from($("editorTable").querySelectorAll("select"));
  rows.forEach(sel => {
    if (transitions[sel.dataset.state]) transitions[sel.dataset.state][sel.dataset.symbol] = sel.value;
  });
  // Existing editor may not match newly typed state/alphabet fields; require rebuild first.
  if (rows.length !== states.length * alphabet.length || rows.some(sel => !states.includes(sel.dataset.state) || !alphabet.includes(sel.dataset.symbol))) {
    return message("After changing states or alphabet, press Reset to preset to refresh the transition editor, then edit the transition rules.", true);
  }
  for (const s of states) for (const a of alphabet) {
    if (!transitions[s]?.[a] || !states.includes(transitions[s][a])) return message(`Missing or invalid transition for state ${s} and symbol ${a}.`, true);
  }
  dfa = {name:"Custom DFA", states, alphabet, start, finals, transitions};
  $("preset").value = "custom";
  $("builderMessage").textContent = "Custom DFA applied successfully.";
  $("builderMessage").style.color = "var(--green)";
  $("resultBox").className = "result-box neutral";
  $("resultBox").innerHTML = '<span class="result-symbol">✓</span><div><strong>Custom DFA loaded</strong><p>Enter a string to test your automaton.</p></div>';
  $("trace").innerHTML = '<div class="empty-state">Run a string to see the execution trace.</div>';
  $("traceCount").textContent = "0 steps";
  lastRun = null; renderAll();
}
function message(msg, error) { $("builderMessage").textContent = msg; $("builderMessage").style.color = error ? "var(--red)" : "var(--green)"; }

$("preset").addEventListener("change", e => {
  if (e.target.value === "custom") {
    $("builderMessage").textContent = "Edit the fields and transition rules, then apply your DFA.";
    return;
  }
  loadPreset(e.target.value);
});
$("runBtn").addEventListener("click", simulate);
$("inputString").addEventListener("keydown", e => { if (e.key === "Enter") simulate(); });
document.querySelectorAll("[data-example]").forEach(btn => btn.addEventListener("click", () => {
  $("inputString").value = btn.dataset.example; simulate();
}));
$("stateNames").addEventListener("change", () => {
  const states = csv($("stateNames").value);
  if (states.length && new Set(states).size === states.length) updateStartOptions(states.includes(dfa.start) ? dfa.start : states[0]);
});
$("refreshEditor").addEventListener("click", refreshBuilderEditor);
$("applyDfa").addEventListener("click", applyCustom);
$("resetDfa").addEventListener("click", () => loadPreset($("preset").value === "custom" ? "ends1" : $("preset").value));
$("editorTable").addEventListener("change", e => {
  if (e.target.matches("select")) {
    dfa.transitions[e.target.dataset.state][e.target.dataset.symbol] = e.target.value;
  }
});
loadPreset("ends1");
